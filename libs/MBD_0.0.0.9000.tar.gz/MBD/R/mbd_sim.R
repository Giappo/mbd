#' @author Giovanni Laudanno
#' @title Creates simulated trees under the multiple birth death process
#' @description mbd_sim produces simulated trees including multiple speciations at the same time.
#' @param pars vector of parameters:
#' \itemize{
#'   \item pars[1] is the multiple speciation trigger rate;
#'   \item pars[2] is the extinction rate;
#'   \item pars[3] is the single-lineage speciation probability.
#' }
#' @param soc Sets whether stem or crown age should be used (1 or 2).
#' @param age The age of the tree.
#' @param cond Set 1 if you want to condition on stem or crown age and non-extinction of the phylogeny. Set 0 otherwise.
#' @param tips_interval Sets tips boundaries constrain on simulated dataset.
#' @return The function returns a list of L table, branching times and number of extinct species.
#' \itemize{
#'   \item brts are the branching times;
#'   \item tes is a tree-object corresponding to the reconstructed phylogenetic tree;
#'   \item tas is a tree-object corresponding to the full phylogenetic tree;
#'   \item extinct_species is the number of species gone extinct before the present time;
#'   \item L is a matrix of all species where the columns are:
#'   \itemize{
#'      \item first is the time at which a species is born;
#'      \item second is the label of the parent of the species; positive and negative values only indicate whether the species belongs to the left or right crown lineage;
#'      \item third is the label of the daughter species itself; positive and negative values only indicate whether the species belongs to the left or right crown lineage;
#'      \item fourth is the time of extinction of the species. If this is equal to -1, then the species is still extant.
#'   }
#' }
#'
#' @examples
#' out = MBD:::mbd_sim( pars=c(2.5,0.1,0.1),soc=2,age=10,cond=1,tips_interval=c(0,Inf) )
#' plot(out$tas)
#' plot(out$tes)
#' out$L
#' @export
mbd_sim=function(pars,soc=2,age=10,cond=1,tips_interval=c(0,Inf),multiple_births_interval=c(0,Inf))
  {
  if (multiple_births_interval[2]<multiple_births_interval[1] || tips_interval[2]<tips_interval[1]){print("ERROR! Check again your settings.");break}
  lambda=pars[1]; mu=pars[2]; q=pars[3]; N0=soc
  tips=-1; conditioning_on_survival=cond; multiple_births_check = 0;
  while ( tips<tips_interval[1] | tips>tips_interval[2] | conditioning_on_survival | multiple_births_check == 0)
    {
    total_count=N0
    pool=1:N0
    while (total_count==N0 | length(pool)<N0)
      {
      total_count=N0
      N=N0
      pool=c(-1,2)
      t=age
      L = matrix(0,nrow=1e6,4)
      L[,4]=-1
      L[,3]=0
      L[1,1:4] = c(t,0,-1,-1)
      L[2,1:4] = c(t,-1,2,-1)
      while (t>0)
        {
        N=length(pool)
        deltaT=rexp(1,rate=(lambda+N*mu))
        outcome=sample(c(-1,1),size=1,prob = c(N*mu,lambda))
        deltaN=rbinom(n=1,size=N,prob=q)*(outcome==1)-1*(outcome==-1)
        t=t-deltaT
        if (deltaN>0 & t>0)
          {
          if (N>1) {parents=sample(pool,replace = F,size=deltaN)}else{parents=pool}
          new_interval=(total_count+1):(total_count+deltaN)
          L[new_interval,1]=t#-(deltaN:1)*1e-5 add this if you need separate time points
          L[new_interval,2]=parents
          L[new_interval,3]=abs(new_interval)*sign(parents)

          pool=c(pool, abs(new_interval)*sign(parents) )
          total_count=total_count+deltaN
          }
        if (deltaN<0 & t>0)
          {
          if (N>1) {dead=sample(pool,replace = F,size=1)}else{dead=pool}
          # dead=abs(dead)
          L[abs(dead),4]=t
          pool=pool[pool!=dead]
          }
        # print(pool)
        }
      }
    L=L[(1:total_count),]
    extinct_species = sum(L[,4]!=-1)
    #tips check
    tips=length(L[,4][L[,4]==-1])
    #survival of crown check
    alive=L[L[,4]==-1,]
    alive=matrix(alive,ncol=4)
    conditioning_on_survival = ( length( unique(sign(alive[,3])) )!=2 )*cond
    #multiple births check
    births=unlist(unname(sort(DDD:::L2brts(L,dropextinct = T),decreasing = T)) )
    multiple_births_in_reconstructed_tree = sum( duplicated(births) )
    multiple_births_check = (multiple_births_in_reconstructed_tree>=multiple_births_interval[1] && multiple_births_in_reconstructed_tree<=multiple_births_interval[2])
    }
  time_points=unlist(unname(sort(DDD:::L2brts(L,dropextinct = T),decreasing = T)) )
  brts = -sort(abs(as.numeric(time_points)),decreasing = TRUE)
  tes = DDD:::L2phylo(L,dropextinct = T)
  tas = DDD:::L2phylo(L,dropextinct = F)
  #   plot(tas)
  #   plot(tes)
  out = list(brts=brts,tes = tes, tas = tas, extinct_species=extinct_species,L = L, multiple_births = multiple_births_in_reconstructed_tree)
  return(out)
  }

#' @author Giovanni Laudanno
#' @title Creates a full simulated dataset of trees under the multiple birth death process
#' @description mbd_sim_dataset produces a full dataset of max_sims simulated trees including multiple speciations at the same time.
#' @param pars vector of parameters:
#' \itemize{
#'   \item pars[1] is the multiple speciation trigger rate;
#'   \item pars[2] is the extinction rate;
#'   \item pars[3] is the single-lineage speciation probability.
#' }
#' @param soc stands for stem or crown. Set 1 for stem or 2 for crown.
#' @param age is the age of the tree.
#' @param cond conditions on the survival of the crown (or the stem). Set to 1 if you want to condition on crown survival. Else set 0.
#' @param edge the program automatically detects the (estimated) average number of tips. "edge" defines the width of the spread around the mean.
#' @param tips_interval You can also define the tips_interval as you can usually do with a standard usage of mbd_sim.
#' @return The function returns a list of brts vectors, one for each of the max_sims simulations.
#' It also saves those in a file called "sim_data" and saves all the settings in a "general_settings" file.
#' N.B.: At each call of the function you overwrite the previous files.
#'
#' @examples
#' out = MBD:::mbd_sim_dataset( pars=c(2.5,0.1,0.1),soc=2,age=10,cond=1,edge=Inf )
#' @export
mbd_sim_dataset = function(sim_pars=c(2.5,0.1,0.10),soc=2,cond=1,age=10,max_sims=1000,tips_interval = c(0,Inf),edge=Inf,multiple_births_interval=c(0,Inf)){
  # mbd_sim_dataset creates a full simulated dataset of "max_sims" trees
  #"edge" gives the extent of fluctuations around the mean that i want to consider

  N0=soc
  if (edge!=Inf && tips_interval == c(0,Inf) ){
    estimation=MBD:::mbd_P_eq(test_parameters=sim_pars,age=age,max_number_of_species = 3000, precision = 50L,soc=soc,output=0);
    max_tips=round(estimation$avg_n*(1+edge));
    min_tips=max(0,round(estimation$avg_n*(1-edge)));
    tips_interval=c(min_tips,max_tips) #c(10,45) #setting the upper limit over 50 may be a problem #min and max number of tips for simulated trees
  }

  #-----------------------------------------------------------------------------------------------
  #simulate trees
  sim_data=vector("list",max_sims)
  ext_species=rep(NA,max_sims)
  for (s in 1:max_sims){
    simulation=MBD:::mbd_sim(pars=sim_pars,soc=soc,age=age,cond=cond,tips_interval = tips_interval,multiple_births_interval=multiple_births_interval)
    sim_data[[s]]=simulation$brts
    ext_species[s]=simulation$extinct_species
  }

  max_k=(N0-1)+(is.list(sim_data))*max(sapply(sim_data, length))+(1-is.list(sim_data))*length(sim_data)
  if (is.list(sim_data)){
    all_the_births=sapply(sim_data,FUN = function(brts){return(MBD:::brts2time_intervals_and_births(brts)$births)})
  }else{
    all_the_births=MBD:::brts2time_intervals_and_births(sim_data)$births
  }
  max_b=max(unlist(all_the_births))
  #-----------------------------------------------------------------------------------------------
  #saving sims and settings
  if (file.exists("data/sim_data")){suppressWarnings( file.remove("data/sim_data") )}
  save(sim_data,file="data/sim_data")
  if (file.exists("data/general_settings")){suppressWarnings( file.remove("data/general_settings") )}
  save(sim_pars,soc,age,cond,max_sims,tips_interval,max_k,max_b,ext_species,file="data/general_settings")
  return(sim_data)
}

#load(file="data/sim_data");load(file="data/general_settings");hist( unlist(lapply(sim_data,length)),20 )

