#' @author Giovanni Laudanno
#' @title Maximization of the loglikelihood under a multiple birth-death diversification model
#' @description mbd_ML computes the maximum likelihood estimates of the parameters of a multiple birth-death diversification model for a given set of phylogenetic branching times. It also outputs the corresponding loglikelihood that can be used in model comparisons.
#' @param brts A set of branching times of a phylogeny.
#' @param initparsopt The initial values of the parameters that must be optimized
#' @param idparsopt The ids of the parameters that must be optimized. The ids are defined as follows:
#' \itemize{
#' \item id == 1 corresponds to lambda (multiple speciation trigger rate)
#' \item id == 2 corresponds to mu (extinction rate)
#' \item id == 3 corresponds to q (single-lineage speciation probability)
#' }
#' @param idparsfix The ids of the parameters that should not be optimized. The default is to fix all parameters not specified in idparsopt.
#' @param parsfix The values of the parameters that should not be optimized.
#' @param missnumspec The number of species that are in the clade but missing in the phylogeny.
#' @param cond Set 1 if you want to condition on stem or crown age and non-extinction of the phylogeny. Set 0 otherwise.
#' @param soc Sets whether stem or crown age should be used (1 or 2).
#' @param tips_interval It takes into account tips boundaries constrain on simulated dataset.
#' @param res Sets the maximum number of species for which a probability must be computed, must be larger than 1 + length(brts).
#' @param tol Sets the tolerances in the optimization. Consists of:
#' \itemize{
#' \item reltolx = relative tolerance of parameter values in optimization
#' \item reltolf = relative tolerance of function value in optimization
#' \item abstolx = absolute tolerance of parameter values in optimization
#' }
#' @param max_iter Sets the maximum number of iterations in the optimization.
#' @param changeloglikifnoconv If TRUE the loglik will be set to -Inf if ML does not converge.
#' @param optimmethod Method used in optimization of the likelihood. Current default is 'subplex'. Alternative is 'simplex' (default of previous versions).
#' @param methode Set "sexpm" if you want to use sexpm. Set "expo" if you want to use expoRkit. Set "lsoda" if you want to use "lsoda".
#' @return The output is a dataframe containing estimated parameters and maximum
#' loglikelihood. The computed loglikelihood contains the factor q! m! / (q + m)!
#' where q is the number of species in the phylogeny and m is the number of
#' missing species, as explained in the supplementary material to Etienne et al. 2012.
#'
#' @examples
#' set.seed(11)
#' test_pars = c(1.6,0.1,0.08)
#' simulated_data = MBD:::mbd_sim( pars=test_pars,soc=2,age=10,cond=1 )
#' plot(simulated_data$tas)
#' MBD:::mbd_ML(brts=simulated_data$brts, initparsopt = 0.11 ,idparsopt = 3,
#' idparsfix = 1:2 ,parsfix = test_pars[1:2],missnumspec=0,cond=1, soc = 2)
#' @export
mbd_ML=function(brts, initparsopt,idparsopt,idparsfix = (1:3)[-idparsopt],parsfix,missnumspec=0,cond=1, soc = 2,tips_interval=c(0,Inf),res = 10*(1+length(brts)+missnumspec),tol = c(1E-3, 1E-4, 1E-6), maxiter = 1000 * round((1.25)^length(idparsopt)), changeloglikifnoconv = FALSE,optimmethod = 'subplex',methode="expo")
  {# bracket#1
  # - tol = tolerance in optimization
  # - changeloglikifnoconv = if T the loglik will be set to -Inf if ML does not converge
  # - maxiter = the maximum number of iterations in the optimization
  # - changeloglikifnoconv = if T the loglik will be set to -Inf if ML does not converge
  # - optimmethod = 'subplex' (current default) or 'simplex' (default of previous versions)

  if (missing(parsfix)&&(length(idparsfix)==0)){parsfix=NULL}

  options(warn=-1)
  namepars = c("lambda","mu","q"); Npars = length(namepars); #if you add more parameters to your model just change this
  failpars=rep(-1,Npars);names(failpars)=namepars; #those are the parameters that you get if something goes sideways
  if(is.numeric(brts) == FALSE)
    {# bracket#2
  cat("The branching times should be numeric.\n")
  out2 = data.frame(t(failpars), loglik = -1, df = -1, conv = -1)
  } else {
  idpars = sort(c(idparsopt,idparsfix))
  if ( (sum(idpars == (1:Npars)) != Npars) || (length(initparsopt) != length(idparsopt)) || (length(parsfix) != length(idparsfix)) )
      {# bracket#3
  cat("The parameters to be optimized and/or fixed are incoherent.\n")
  out2 = data.frame(t(failpars), loglik = -1, df = -1, conv = -1)
  } else {
  if(length(namepars[idparsopt]) == 0) { optstr = "nothing" } else { optstr = namepars[idparsopt] }
  cat("You are optimizing",optstr,"\n")
  if(length(namepars[idparsfix]) == 0) { fixstr = "nothing" } else { fixstr = namepars[idparsfix] }
  cat("You are fixing",fixstr,"\n")
  cat("Optimizing the likelihood - this may take a while.","\n")
  flush.console()
# trparsopt = initparsopt/(1 + initparsopt) # I don't understand how this works
# trparsopt[which(initparsopt == Inf)] = 1  # I don't understand how this works
# trparsfix = parsfix/(1 + parsfix)         # I don't understand how this works
# trparsfix[which(parsfix == Inf)] = 1      # I don't understand how this works
  trparsopt = initparsopt  #I added this like because i don't understand previous lines
  trparsfix = parsfix      #I added this like because i don't understand previous lines
  optimpars = c(tol,maxiter)
  initloglik = MBD:::mbd_loglik_choosepar(trparsopt = trparsopt,trparsfix = trparsfix,idparsopt = idparsopt,idparsfix = idparsfix,brts = brts,missnumspec = missnumspec, cond=cond,soc = soc, tips_interval = tips_interval, methode = methode) #there's no pars2 here and instead 3 more args at the end
  cat("The loglikelihood for the initial parameter values is",initloglik,"\n")
  flush.console()
  if(initloglik == -Inf)
        {# bracket#4
  cat("The initial parameter values have a likelihood that is equal to 0 or below machine precision. Try again with different initial values.\n")
  out2 = data.frame(t(failpars), loglik = -1, df = -1, conv = -1)
  } else {
  out = DDD:::optimizer(optimmethod = optimmethod,optimpars = optimpars,fun = MBD:::mbd_loglik_choosepar,trparsopt = trparsopt,trparsfix = trparsfix,idparsopt = idparsopt,idparsfix = idparsfix,brts = brts,missnumspec = missnumspec, cond=cond,soc = soc, tips_interval = tips_interval, methode = methode)
  if(out$conv != 0)
          {# bracket#5
  cat("Optimization has not converged. Try again with different initial values.\n")
  out2 = data.frame(t(failpars), loglik = -1, df = -1, conv = -1)
  } else {
  MLtrpars = as.numeric(unlist(out$par))
  # MLpars = MLtrpars/(1-MLtrpars)           # I don't understand how this works
  MLpars = MLtrpars                          # I don't understand how this works
  MLpars1 = rep(0,Npars); names(MLpars1)=namepars
  MLpars1[idparsopt] = MLpars
  if(length(idparsfix) != 0) { MLpars1[idparsfix] = parsfix }
  ML = as.numeric(unlist(out$fvalues))
  out2 = data.frame(t(MLpars1), loglik = ML, df = length(initparsopt), conv = unlist(out$conv))

  tobeprint="Maximum likelihood parameter estimates:"
  for (ii in 1:Npars){
   tobeprint=paste(tobeprint,paste(names(MLpars1[ii]),":",sep = ""),MLpars1[ii])
  }
  s1 = sprintf(tobeprint)

  if(out2$conv != 0 & changeloglikifnoconv == T) { out2$loglik = -Inf }
  s2 = sprintf('Maximum loglikelihood: %f',ML)
  cat("\n",s1,"\n",s2,"\n\n")
          }# bracket#5
        }# bracket#4
      }# bracket#3
    }# bracket#2
  invisible(out2)
  }# bracket#1

mbd_ML_cluster = function(s,initparsopt=c(1.8,0.2,0.2),idparsopt=1:3,parsfix=NULL){
  load(file="data/general_settings")
  load(file="data/sim_data")

  res=mbd_ML(brts=sim_data[[s]],
         initparsopt=initparsopt,
         idparsopt=idparsopt,
         idparsfix = (1:3)[-idparsopt],
         parsfix = parsfix,
         missnumspec=0,
         cond= cond,
         soc = soc,
         tips_interval=tips_interval,
         res = 10*(1+length(brts)+missnumspec),
         tol = c(1E-3, 1E-4, 1E-6),
         maxiter = 1000 * round((1.25)^length(idparsopt)),
         changeloglikifnoconv = FALSE,
         optimmethod = 'subplex')

  additional_species = sum( duplicated(sim_data[[s]]) )
  write.table(matrix(c(res[1:4],additional_species,res[5:6]),ncol = dim(res)[2]+1),file = "mbd_MLE.txt",append = T,row.names = F,col.names = F, sep = ",")
}
#for (s in 1:20){MBD:::mbd_ML_cluster(s=s)}
