#' @title Internal MBD function
#' @description Internal MBD function.
#' @details This is not to be called by the user.
mbd_loglik_choosepar=function(trparsopt,trparsfix,idparsopt,idparsfix,brts,cond=1,soc=2,tips_interval=c(0,Inf),missnumspec=0,methode = "sexpm"){
  #This function provides a likelihood for a subset of parameters. This is built to work inside mbd_minusLL_vs_single_parameter or any optimizer like optim or subplex
  #idparsopt are the ids for parameters you want to analyze
  #trparsopt are the values for parameters you want to analyze
  #idparsfix are the ids of the parameters you want to fix
  #trparsfix are the values for parameters you want to fix

  namepars = c("lambda","mu","q"); Npars = length(namepars);
  # idparsopt=(1:3)[-c(idparsfix)] #this argument is useless but I let the user specify it because Rampal also did it (for some reason)
  trpars1 = rep(0,Npars)
  trpars1[idparsopt] = trparsopt
  if(length(idparsfix) != 0)
  {
    trpars1[idparsfix] = trparsfix
  }
  if( min(trpars1[1:Npars]) < 0 || trpars1[1] <= trpars1[2] ){loglik = -Inf}else
    {
    loglik=MBD:::mbd_loglik(pars=trpars1,brts=brts,cond=cond,soc=soc,tips_interval=tips_interval,methode = methode)
    }
  if(is.nan(loglik) || is.na(loglik))
  {
    cat("There are parameter values used which cause numerical problems.\n")
    loglik = -Inf
  }
  return(loglik)
}
