#' @title Internal MBD function
#' @description Internal MBD function.
#' @details This is not to be called by the user.
mbd_loglik_rhs = function (t, x, pars){
  #builds right hand side of the ODE set for multiple birth model
  with(as.list(x), {
    starting_vector=x
    transition_matrix=pars
    dx=rep(0,length(starting_vector))
    dx=drop(transition_matrix %*% starting_vector)
    out=(dx)
    names(out)=names(x)
    return(list(out))
  })
}
