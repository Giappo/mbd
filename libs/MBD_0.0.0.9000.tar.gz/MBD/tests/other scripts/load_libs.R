# update.packages(ask=F)
if (.Platform$OS.type=="windows"){
  install.packages("libs/MBD_0.0.0.9000.zip",repos=NULL, type = "source")
  install.packages("libs/DDD_3.4.zip", repos = NULL, type = "source",dependencies = T)
}
if (.Platform$OS.type=="unix"){
  install.packages("libs/MBD_0.0.0.9000.tar.gz",repos=NULL, type = "source")
  install.packages("libs/DDD_3.4.tar.gz", repos = NULL, type = "source",dependencies = T)
}
