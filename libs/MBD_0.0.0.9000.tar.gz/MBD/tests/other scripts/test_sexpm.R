######################## mbd_loglik performance check ####################################
ripetizioni=3;pars=c(2.5,0.1,0.001);time_vs_kmax = res_vs_kmax = matrix(0,ncol=2,nrow=30)
yet_to_calculate=which(time_vs_kmax[,1]==0)
for (kmax in yet_to_calculate){# kmax = 7
  brts=-seq(from=kmax,to=1,by=-1)

  t1 = unname( system.time(for (i in 1:ripetizioni){r1 <- try(MBD::mbd_loglik(pars=pars,brts=brts,cond = 1,methode = "expo" ))} )[3] );
  t2 = unname( system.time(for (i in 1:ripetizioni){r2 <- try(MBD::mbd_loglik(pars=pars,brts=brts,cond = 1,methode = "sexpm"))} )[3] );
  time_vs_kmax[kmax,]=c(t1,t2)
  res_vs_kmax[kmax,]=c(r1,r2)
  print(c(kmax,r1,r2))
}

res_vs_kmax[,2]/res_vs_kmax[,1]
plot(time_vs_kmax[,2]/time_vs_kmax[,1],xlab="number of tips",ylab = "sexpm_time/expoRkit_time")

######################## mbd_ML performance check ####################################
max_iter = 500;sexpm_matrix=expo_matrix=matrix(0,nrow = max_iter,ncol = 6);
tips_interval = c(10,50); cond = 1; age = 10; soc = 2; start_pars= c(1.0,0.2,0.15); sim_pars=c(1.5,0.1,0.1)
yet_to_calculate= (dim(expo_data)+1): max_iter
for (i in yet_to_calculate)
{
print(i)
MLbrts[[i]]=MBD:::mbd_sim(pars=sim_pars,soc = soc,age = age,cond = cond,tips_interval = tips_interval,min_amount_multiple_births = 3)$brts; print(MLbrts[[i]])
expo_time[i] = system.time( expo_res[[i]] <- MBD:::mbd_ML(brts=MLbrts[[i]],initparsopt = start_pars,idparsopt = 1:3,cond = cond,soc = soc,tips_interval = tips_interval, methode = "expo") )[3]
# sexpm_time[i] = system.time( sexpm_res[[i]] <- MBD:::mbd_ML(brts=MLbrts[[i]],initparsopt = start_pars,idparsopt = 1:3,cond = cond,soc = soc,tips_interval = tips_interval, methode = "sexpm") )[3]
expo_matrix[i,]=unlist(unname(expo_res[[i]]))
# sexpm_matrix[i,]=unlist(unname(sexpm_res[[i]]))
}
#data analysis
expo_data[which(expo_matrix[,1]!=0),] = expo_matrix[expo_matrix[,1]!=0,];dim(expo_data2)
# sexpm_data= sexpm_matrix[sexpm_matrix[,1]!=0,];dim(sexpm_data)
colMeans(expo_data[,1:3])
# colMeans(sexpm_data[,1:3])
apply(FUN = median,X = expo_data[,1:3],MARGIN = 2)
# apply(FUN = median,X = sexpm_data[,1:3],MARGIN = 2)
sim_pars
for (jj in 1:3){ #expo_results
  hist(expo_data[,jj],breaks = 20,main = "expoRkit_results",xlab = paste("parameter number",jj)) ; abline(v=sim_pars[jj],col="red");
}
# for (jj in 1:3){ #sexpm_results
#   hist(sexpm_data[,jj],breaks = 20,main = "sexpm_results",xlab = paste("parameter number",jj)) ; abline(v=sim_pars[jj],col="red");
# }
#results vs number of multiple births
multiple_births = rep(0,dim(expo_data)[1])
for (ii in 1:dim(expo_data)[1]){
  # print(ii)
  # print(MLbrts[[ii]])
  multiple_births[ii] = ( sum( duplicated(MLbrts[[ii]]) ) )
}
print(multiple_births)

coords=vector("list");
expo_means = sexpm_means = expo_medians = sexpm_medians = matrix(NA,nrow=max(multiple_births),ncol=3)
for (k in 1:max(multiple_births)){
  coords[[k]]=which(multiple_births==k)
}
for (jj in 1:3){##expo
  for (k in 1:max(multiple_births)){
    expo_means[k,jj] = mean(expo_data[coords[[k]],jj])
    expo_medians[k,jj] = median(expo_data[coords[[k]],jj])
  }
  plot(expo_data[,jj]~multiple_births,main=paste("Parameter",jj,"vs number of multiple births\n expoRkit method"),ylab = paste("parameter number",jj))
  # points(expo_means[,jj][is.nan(expo_means[,jj])==0]~(1:max(multiple_births))[is.nan(expo_means[,jj])==0],col="blue",pch=23,cex=2)
  points(expo_medians[,jj][is.nan(expo_medians[,jj])==0]~(1:max(multiple_births))[is.nan(expo_medians[,jj])==0],col="blue",pch=23,cex=2,lwd=2)
  abline(a=sim_pars[jj],b = 0, col= "red")
}

# for (jj in 1:3){##sexpm
#   for (k in 1:max(multiple_births)){
#     sexpm_means[k,jj] = mean(sexpm_data[coords[[k]],jj])
#     sexpm_medians[k,jj] = median(sexpm_data[coords[[k]],jj])
#   }
#   plot(sexpm_data[,jj]~multiple_births,main=paste("Parameter",jj,"vs number of multiple births\n sexpm method"),ylab = paste("parameter number",jj))
#   # points(sexpm_means[,jj][is.nan(sexpm_means[,jj])==0]~(1:max(multiple_births))[is.nan(sexpm_means[,jj])==0],col="blue",pch=23,cex=2)
#   points(sexpm_medians[,jj][is.nan(sexpm_medians[,jj])==0]~(1:max(multiple_births))[is.nan(sexpm_medians[,jj])==0],col="blue",pch=23,cex=2,lwd=2)
#   abline(a=sim_pars[jj],b = 0, col= "red")
# }

#badguys analysis
cbind(expo_data[,4],sexpm_data[,4])
bad_guys = rep(0, dim(expo_data)[1] )
for (ii in 1:dim(expo_data)[1]){
  bad_guys[ii] = (expo_data[ii,4]!=sexpm_data[ii,4])
}
sum(bad_guys)/( dim(expo_data)[1] )

bad_number=13

the_bad=which(bad_guys==1)[bad_number]
bad_brts = MLbrts[[the_bad]]
bad_pars_sexpm = sexpm_matrix[the_bad,1:3]
bad_pars_expo = expo_matrix[the_bad,1:3]
MBD:::mbd_loglik(pars=bad_pars_sexpm,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "sexpm")
MBD:::mbd_loglik(pars=bad_pars_sexpm,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "expo")
MBD:::mbd_loglik(pars=bad_pars_expo,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "sexpm")
MBD:::mbd_loglik(pars=bad_pars_expo,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "expo")

LL_sexpm_1 = MBD:::mbd_loglik_choosepar(trparsopt = bad_pars_sexpm,trparsfix = NULL,idparsopt = 1:3,idparsfix = NULL,
                           missnumspec = 0,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "sexpm")
LL_sexpm_2 = MBD:::mbd_loglik_choosepar(trparsopt = bad_pars_sexpm,trparsfix = NULL,idparsopt = 1:3,idparsfix = NULL,
                           missnumspec = 0,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "expo")
LL_expo_1 = MBD:::mbd_loglik_choosepar(trparsopt = bad_pars_expo,trparsfix = NULL,idparsopt = 1:3,idparsfix = NULL,
                           missnumspec = 0,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "sexpm")
LL_expo_2 =MBD:::mbd_loglik_choosepar(trparsopt = bad_pars_expo,trparsfix = NULL,idparsopt = 1:3,idparsfix = NULL,
                           missnumspec = 0,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "expo")

sexpm_check = all.equal(LL_sexpm_1,LL_sexpm_2); if (sexpm_check!=1){cat("using best parameters found with sexpm the two methods give different likelihoods for bad_guy number:",bad_number,"\n")}
expo_check =  all.equal(LL_expo_1,LL_expo_2);if (expo_check!=1){cat("using best parameters found with expo the two methods give different likelihoods for bad_guy number:",bad_number,"\n")}
if (LL_sexpm_1>LL_expo_1){cat("sexpm wins \n")}else{cat("expo wins \n")}


###################### Trying to debug the function
nsim=23;missnumspec=0
pars=c( 0.999421296296296 , 0.225270061728395 , 0.65829475308642 )
MBD::mbd_loglik(pars=pars,brts = MLbrts[[nsim]],soc = soc,cond = cond,tips_interval = tips_interval,methode = "expo")
MBD::mbd_loglik(pars=pars,brts = MLbrts[[nsim]],soc = soc,cond = cond,tips_interval = tips_interval,methode = "sexpm",debug_check = 1)

maxima=head(sort(transition_matrix,decreasing = T),10)
minima=head(sort(transition_matrix,decreasing = F),10)
max_coordinates = min_coordinates = vector("list",10)
for (i in 1:10){
 max_coordinates[[i]]=which(transition_matrix==maxima[i],arr.ind = T)
 min_coordinates[[i]]=which(transition_matrix==minima[i],arr.ind = T)
}
subA=transition_matrix[5:21,5:21]
MBD:::myheatmap(subA)
rcond(subA)
all.equal( rsexpm::sexpm(subA),expm::expm(subA) )
######################################## sub-matrix
select_critical_submatrix = function(transition_matrix,dimensionality=10,max_iter=1e6){
cond_test=1e20;cond_min=1e20;
N=dim(transition_matrix)[1]
i=0; prev_status=0;
while ( (i <- i+1) <= max_iter){
  sample1=sample(dimensionality,x = 1:N)
  sample1=sort(sample1)
  submatrix=transition_matrix[sample1,sample1]
  cond_test=rcond(submatrix)
  if (cond_test < cond_min && max(submatrix)>0){
    cond_min=cond_test
    best_submatrix = submatrix
  }

  status=floor((i/max_iter)*100)/100
  if (status != prev_status){print(status)}
  prev_status=status
}
# MBD:::myheatmap(best_submatrix)
# rcond(best_submatrix)
sexpm_test = rsexpm::sexpm(best_submatrix)
expm_test =  expm::expm(best_submatrix)
# MBD:::myheatmap( sexpm_test )
# MBD:::myheatmap( expm_test  )
# hist( log(sexpm_test) )
# hist( log(expm_test)  )
# sort(sexpm_test)
# sort(expm_test)
similarity = sum ( abs(expm_test-sexpm_test)<=expm_test*(10^-3) )/prod(dim(expm_test))
cat("Similarity up to the third digit between the two exponentiations is", similarity, "\n" )
return(list(submatrix = best_submatrix, condition_number = rcond(best_submatrix)))
}
test = select_critical_submatrix(transition_matrix)
submatrix = test$submatrix
sexpm_test = rsexpm::sexpm(submatrix)
expm_test =  expm::expm(submatrix)
####################################### quad test
transition_matrix = as.matrix(unname(transition_matrix)); rm(t_expm,t_sexpm);repetitions = 30;
t_expm <- system.time( for (i in 1:repetitions){expm_test <- expm:::expm(transition_matrix)} )
t_sexpm <- system.time( for (i in 1:repetitions){sexpm_test <- (rsexpm:::sexpm(transition_matrix))} )
print(t_expm);print(t_sexpm);
# quad_version = rsexpm::as.quadmatrix(transition_matrix); sexpm_test_with_double=rsexpm:::cast2double( rsexpm:::sexpm(quad_version) )

MBD:::myheatmap(expm_test)
MBD:::myheatmap(sexpm_test)
all.equal(expm_test,sexpm_test)


