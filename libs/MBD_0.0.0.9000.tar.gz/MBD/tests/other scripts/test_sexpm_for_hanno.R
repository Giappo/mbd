######################## mbd_loglik performance check ####################################
ripetizioni=3;pars=c(2.5,0.1,0.001);time_vs_kmax = res_vs_kmax = matrix(0,ncol=2,nrow=30)
yet_to_calculate=which(time_vs_kmax[,1]==0)
for (kmax in yet_to_calculate){# kmax = 7
  brts=-seq(from=kmax,to=1,by=-1)

  t1 = unname( system.time(for (i in 1:ripetizioni){r1 <- try(MBD::mbd_loglik(pars=pars,brts=brts,cond = 1,methode = "expo" ))} )[3] );
  t2 = unname( system.time(for (i in 1:ripetizioni){r2 <- try(MBD::mbd_loglik(pars=pars,brts=brts,cond = 1,methode = "sexpm"))} )[3] );
  time_vs_kmax[kmax,]=c(t1,t2)
  res_vs_kmax[kmax,]=c(r1,r2)
  print(c(kmax,r1,r2))
}

res_vs_kmax[,2]/res_vs_kmax[,1]
plot(time_vs_kmax[,2]/time_vs_kmax[,1],xlab="number of tips",ylab = "sexpm_time/expoRkit_time")

######################## mbd_ML performance check ####################################
max_iter = 500;sexpm_matrix=expo_matrix=matrix(0,nrow = max_iter,ncol = 6);MLbrts=expo_res=sexpm_res=vector("list",max_iter);expo_time=sexpm_time=rep(0,max_iter)
tips_interval = c(10,50); cond = 1; age = 10; soc = 2; start_pars= c(1.0,0.2,0.15); sim_pars=c(1.5,0.1,0.1)
yet_to_calculate= (which(sexpm_matrix[,1]==0)[1]): max_iter
for (i in yet_to_calculate)
{
  print(i)
  MLbrts[[i]]=MBD:::mbd_sim(pars=sim_pars,soc = soc,age = age,cond = cond,tips_interval = tips_interval,min_amount_multiple_births = 3)$brts; print(MLbrts[[i]])
  expo_time[i] = system.time( expo_res[[i]] <- MBD:::mbd_ML(brts=MLbrts[[i]],initparsopt = start_pars,idparsopt = 1:3,cond = cond,soc = soc,tips_interval = tips_interval, methode = "expo") )[3]
  sexpm_time[i] = system.time( sexpm_res[[i]] <- MBD:::mbd_ML(brts=MLbrts[[i]],initparsopt = start_pars,idparsopt = 1:3,cond = cond,soc = soc,tips_interval = tips_interval, methode = "sexpm") )[3]
  expo_matrix[i,]=unlist(unname(expo_res[[i]]))
  sexpm_matrix[i,]=unlist(unname(sexpm_res[[i]]))
}
colMeans(expo_matrix)
colMeans(sexpm_matrix)
sim_pars

bad_guys = rep(0, dim(expo_matrix)[1] )
for (ii in 1:dim(expo_matrix)[1]){
  bad_guys[ii] = prod(expo_matrix[ii,1:4]!=sexpm_matrix[ii,1:4])
}
first_bad=which(bad_guys==1)[1]
bad_brts = MLbrts[[first_bad]]
bad_pars = sexpm_matrix[first_bad,1:3]
MBD:::mbd_loglik(pars=bad_pars,brts = bad_brts,cond = cond, soc = soc,tips_interval = tips_interval,methode = "sexpm")

###################### Trying to debug the function
nsim=23;missnumspec=0
pars=c( 0.999421296296296 , 0.225270061728395 , 0.65829475308642 )
MBD::mbd_loglik(pars=pars,brts = MLbrts[[nsim]],soc = soc,cond = cond,tips_interval = tips_interval,methode = "expo")
MBD::mbd_loglik(pars=pars,brts = MLbrts[[nsim]],soc = soc,cond = cond,tips_interval = tips_interval,methode = "sexpm",debug_check = 1)

maxima=head(sort(transition_matrix,decreasing = T),10)
minima=head(sort(transition_matrix,decreasing = F),10)
max_coordinates = min_coordinates = vector("list",10)
for (i in 1:10){
  max_coordinates[[i]]=which(transition_matrix==maxima[i],arr.ind = T)
  min_coordinates[[i]]=which(transition_matrix==minima[i],arr.ind = T)
}
subA=transition_matrix[5:21,5:21]
MBD:::myheatmap(subA)
rcond(subA)
all.equal( rsexpm::sexpm(subA),expm::expm(subA) )
####################select critical submatrix out of "matrix from hell" considering condition number#########################
transition_matrix=as.matrix(unname(read.table(file.choose())))
select_critical_submatrix = function(transition_matrix,dimensionality=10,max_iter=1e6){
  cond_test=1e20;cond_min=1e20;
  N=dim(transition_matrix)[1]
  i=0; prev_status=0;
  while ( (i <- i+1) <= max_iter){
    sample1=sample(dimensionality,x = 1:N)
    sample1=sort(sample1)
    submatrix=transition_matrix[sample1,sample1]
    cond_test=rcond(submatrix)
    if (cond_test < cond_min && max(submatrix)>0){
      cond_min=cond_test
      best_submatrix = submatrix
    }
    status=floor((i/max_iter)*100)/100
    if (status != prev_status){print(status)}
    prev_status=status
    # if (max(Im(eigen(submatrix)$values))>0){print(Im(eigen(submatrix)$values))}
  }
  # MBD:::myheatmap(best_submatrix)
  # rcond(best_submatrix)
  sexpm_test = rsexpm::sexpm(best_submatrix)
  expm_test =  expm::expm(best_submatrix)

  # MBD:::myheatmap( sexpm_test )
  # MBD:::myheatmap( expm_test  )
  # hist( log(sexpm_test) )
  # hist( log(expm_test)  )
  # sort(sexpm_test)
  # sort(expm_test)
  digit_precision = 4
  similarity = sum ( abs(expm_test-sexpm_test)<=expm_test*(10^(-digit_precision)) )/prod(dim(expm_test))
  cat("Similarity up to the",digit_precision,"-th digit between the two exponentiations is", similarity, "\n" )
  return(list(submatrix = best_submatrix, condition_number = rcond(best_submatrix)))
}
test = select_critical_submatrix(transition_matrix,max_iter = 1e5,dimensionality = 100)
submatrix = test$submatrix
sexpm_test = rsexpm::sexpm(submatrix)
expm_test =  expm::expm(submatrix)
Im(eigen(submatrix)$values)
Im(eigen(transition_matrix)$values)
##########################################################################################

i=0; max_iter=1e20; dimensionality = 10;N=dim(transition_matrix)[1];best_submatrix=NULL
while ( (i <- i+1) <= max_iter && is.null(best_submatrix)){
  sample1=sample(dimensionality,x = 1:N)
  sample1=sort(sample1)
  submatrix=transition_matrix[sample1,sample1]
  spettro=eigen(submatrix)$values
  if (any(Im(spettro))!=0){
    best_submatrix = submatrix
  }
}
print(best_submatrix)

