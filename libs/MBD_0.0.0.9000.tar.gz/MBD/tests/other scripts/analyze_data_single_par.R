rm(list = setdiff(ls(), "res"))
home_dir=NULL
if (is.null(home_dir)){
  if (.Platform$OS.type=="windows"){home_dir = normalizePath("../",winslash = "/")}
  if (.Platform$OS.type=="unix"){home_dir = substring(getwd(),1,13)} #this is set to work with home directory of the cluster  
}
if (file.exists(paste(home_dir,'/mbd_like/sim_data',sep = ''))){
  load(paste(home_dir,'/mbd_like/sim_data',sep = ''),envir=.GlobalEnv) 
}
if (file.exists(paste(home_dir,'/mbd_like/general_settings',sep = ''))){
  load(paste(home_dir,'/mbd_like/general_settings',sep = ''),envir=.GlobalEnv)
}
results_sp = read.csv(file.choose(),header = F)

q_avg=mean(results_sp[,1])
q_median=median(results_sp[,1])
q_std=sd(results_sp[,1])
quantile(results_sp[,1],probs =  c(0.25,0.50,0.75))
#plots
hist(results_sp[,1],breaks = 10,xlab = "q est", main = paste("q estimations over",length(results_sp[,1]),"trees\n true =",sim_pars[3],"median=",q_median,"sd=",round(q_std,digits = 3)))
plot(results_sp[,1]~results_sp[,2],ylab = "q est",xlab = "# tips", main = "q estimations vs # tips")

all_trees=sort(unlist(lapply(sim_data,length)))
estimated_trees=results_sp[,2]
bad_trees=!(all_trees%in%estimated_trees)

hist(all_trees , main = "# tips for all trees")
hist( all_trees[bad_trees] , main = "# tips for not evaluated trees")
