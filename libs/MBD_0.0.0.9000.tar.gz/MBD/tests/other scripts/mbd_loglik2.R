library(pracma)

#' @title Internal MBD function
#' @description Internal MBD function.
#' @details This is not to be called by the user.
create_A=function(max_number_of_species,lambda,mu,q,k){
  nvec = 0:max_number_of_species
  M = lambda * hyperA_HannoX(N = max_number_of_species,k = k,q = q)
  diag(M) = (-lambda)*c( (1-(1-q)^(k+( nvec[1:max_number_of_species] ) )),0 ) - mu*(nvec+k)
  M[row(M) == col(M) - 1] = mu*nvec[2:(max_number_of_species+1)]
  # M = as(M, "sparseMatrix") #if you use this line change ode_matrix in A_operator
  return(M)
}

#' @title Internal MBD function
#' @description Internal MBD function.
#' @details This is not to be called by the user.
create_B=function(max_number_of_species,q,k,b){#lambda * choose(k,b) * q^b  is going to be added in logB in the main script
  k2=k-b
  B = hyperA_HannoX(N = max_number_of_species,k = k2,q = q)
  return(B)
}

#' @title Internal MBD function
#' @description Internal MBD function.
#' @details This is not to be called by the user.
A_operator=function(Q,transition_matrix,time_interval,precision=50L,
                    A_abstol=1e-16,A_reltol=1e-10,methode="both"){
  if (methode=="expo")
  {
    result=expoRkit:::expv(v=Q,x=transition_matrix,t=time_interval,m = precision)
  }else if (methode=="lsoda")
  {
    times=c(0,time_interval)
    # ode_matrix=as.matrix(transition_matrix) #use this only if you use sparsematrices
    ode_matrix=transition_matrix
    result=deSolve::ode(y = Q, times = times, func = MBD:::mbd_loglik_rhs, parms = ode_matrix,atol=A_abstol,rtol=A_reltol)[2,-1]
  }else{
    result=expoRkit:::expv(v=Q,x=transition_matrix,t=time_interval,m = precision)
    #sometimes I get troubles with expoRkit, in this case i perform standard integration with ode
    if (any(is.na(result)) | max(result)<=0)
    {
      times=c(0,time_interval)
      # ode_matrix=as.matrix(transition_matrix) #use this only if you use sparsematrices
      ode_matrix=transition_matrix
      result=deSolve::ode(y = Q, times = times, func = MBD:::mbd_loglik_rhs, parms = ode_matrix,atol=A_abstol,rtol=A_reltol)[2,-1]
    }
  }
  return(result)
}

#' @author Giovanni Laudanno
#' @title Calculates the likelihood for a multiple birth-death process
#' @description mbd_loglik provides the likelihood for a process in which multiple births (from different parents) at the same time are possible.
#' @param pars vector of parameters:
#' \itemize{
#'   \item pars[1] is the multiple speciation trigger rate;
#'   \item pars[2] is the extinction rate;
#'   \item pars[3] is the single-lineage speciation probability.
#' }
#' @param brts A set of branching times of a phylogeny.
#' @param soc Sets whether stem or crown age should be used (1 or 2)
#' @param cond Set 1 if you want to condition on stem or crown age and non-extinction of the phylogeny. Set 0 otherwise.
#' @param tips_interval It takes into account tips boundaries constrain on simulated dataset.
#' @param missnumspec The number of species that are in the clade but missing in the phylogeny.
#' @param methode Set "expo" if you want to use expoRkit. Set "lsoda" if you want to use "lsoda". Use default to use both of them.
#' @param safety_threshold It Determines the precision on the parameters.
#' @return The function returns the natural logarithm of the likelihood for the process.
#'
#' @examples
#' set.seed(11)
#' simulated_data = MBD:::mbd_sim( pars=c(2.5,0.1,0.1),soc=2,age=10,cond=1 )
#' plot(simulated_data$tas)
#' mbd_loglik( pars=c(1.2,0.05,0.1),brts=simulated_data$brts,soc=2,cond=1,missnumspec=0 )
#' @export

#MAIN
mbd_loglik2 = function(pars,brts,soc=2,cond=0,tips_interval=c(0,Inf),missnumspec=0,safety_threshold = 1e-4,methode = "both"){

  #Optional stuff that I might need to run the program one line at the time:
  #brts=sim_data[[1]];missnumspec=0;pars=sim_pars;missing_interval=c(1,Inf)

  #BASIC SETTINGS AND CHECKS
  lambda=pars[1]; mu=pars[2]; q=pars[3]; min_tips=tips_interval[1]; max_tips=tips_interval[2];
  # lambda=round(lambda,digits=4); mu=round(mu,digits=4); q=round(q,digits=4) #do i need more than 4 digits?
  abstol=1e-16; reltol=1e-10;
  condition1 = ( any(is.nan(pars))!=0 | any(is.infinite(pars))!=0 )
  condition2 = ( mu>=lambda | mu<0 | lambda<=0+safety_threshold | q<=0+safety_threshold | q>=1-safety_threshold )
  if (condition1 | condition2){loglik = -Inf}
  else{

    #ADJUSTING DATA
    data=MBD:::brts2time_intervals_and_births(brts)
    time_intervals=c(0,data$time_intervals)
    births=c(0,data$births)
    TT=length(time_intervals)
    brts=suppressWarnings( sort( c(brts,0), decreasing = FALSE ) )
    errors = c(0, (brts[3:TT]-brts[1:(TT-2)]) / 8 )

    timeinterval=seq(-10,0,by=0.05);
    distribution=rep(0,length(timeinterval))
    for (ti in 2:length(births)){
    distribution=distribution+dnorm(timeinterval, mean = brts[ti], sd = errors[ti], log = FALSE)
    }
    plot(distribution)

    brts_coords=which(timeinterval%in%brts)
    brts
    timeinterval[brts_coords]

    beastdata = MBD:::extract_posterior(file_name = beastoutput,maxtree = maxtree)
    beastdata$brts
    brts=lapply(beastdata$dist,mean)




    #SET UP
    N0 = soc #number of starting species
    k_interval = N0 + cumsum(births)
    max_k = max(k_interval)
    max_number_of_species = 30*max_k; #print("i am using 80 now")
    nvec=0:max_number_of_species

    #SETTING INITIAL CONDITIONS (there's always a +1 because of Q0)
    Qi=c(1,rep(0,max_number_of_species))
    Qt=matrix(0,ncol = (max_number_of_species+1), nrow = length(time_intervals))
    Qt[1,]=Qi
    dimnames(Qt)[[2]] = paste("Q",0:max_number_of_species,sep="")
    k=N0 #N0 is the number of species at t=1
    t=2  #t is starting from 2 so everything is ok with birth[t] and time_intervals[t] vectors
    C=rep(1,(length(time_intervals))); D=C
    logB=0;

    #EVOLVING THE INITIAL STATE TO THE LAST BRANCHING POINT
    while ( t<length(time_intervals) ){

      #Applying A operator
      transition_matrix=create_A(max_number_of_species = max_number_of_species,lambda = lambda,mu = mu,q = q,k = k)

#     Qt[t,]=A_operator(Q = Qt[(t-1),],transition_matrix = transition_matrix,time_interval = time_intervals[t],precision = 50L,methode=methode,A_abstol=abstol,A_reltol=reltol)

      integrand = function (tt){
          res=A_operator(Q = Qt[(t-1),],transition_matrix = transition_matrix,time_interval = (tt-brts[t-1]),precision = 50L,methode=methode,A_abstol=abstol,A_reltol=reltol)*
          dnorm(tt, mean = brts[t], sd = errors[t], log = FALSE)
            # ( abs(tt-brts[t])<=1e-0 )
      }
      Qt[t,]=quadv(integrand, a=brts[t-1], b=brts[t+1], tol=1e-10)$Q
      Qt[t,]=negatives_correction(Qt[t,],pars) #it removes some small negative values that can occurr as bugs from the integration process

      #Applying C operator (this is a trick to avoid precision issues)
      C[t]=1/(sum(Qt[t,]))
      Qt[t,]=Qt[t,]*C[t]

      #Applying B operator
      B = create_B(max_number_of_species = max_number_of_species,q = q,k = k,b = births[t])
      # B[(row(B)>(2*col(B)+k-births[t])) | col(B)>row(B) ]=0 #this is a constrain due to maximum number of speciations being (2*n+k-b); probably it is redundant
      # if (max(is.nan(B))>0){print(paste("NaN were produced in the B matrix at time=",t))}
      Qt[t,]=(B %*% Qt[t,])
      Qt[t,]=negatives_correction(Qt[t,],pars) #it removes some small negative values that can occurr as bugs from the integration process
      logB = logB + log(lambda) + lchoose(k,births[t]) + births[t]*log(q)

      #Applying D operator (this works exactly like C)
      D[t]=1/(sum(Qt[t,]))
      Qt[t,]=Qt[t,]*D[t]

      #Updating running parameters
      k=k+births[t]
      t=t+1
    }

    #Applying A operator from the last branching time to the present
    transition_matrix=create_A(max_number_of_species = max_number_of_species,lambda = lambda,mu = mu,q = q,k = k)
    Qt[t,]=A_operator(Q = Qt[(t-1),],transition_matrix = transition_matrix,time_interval = (brts[t]-brts[t-1]),precision = 50L,methode=methode,A_abstol=abstol,A_reltol=reltol)
    # integrand = function (tt){
    #   res=A_operator(Q = Qt[(t-1),],transition_matrix = transition_matrix,time_interval = (tt-brts[t-1]),precision = 50L,methode=methode,A_abstol=abstol,A_reltol=reltol)*
    #     dnorm(tt, mean = brts[t], sd = errors[t], log = FALSE)
    #   # ( abs(tt-brts[t])<=1e-0 )
    # }
    # Qt[t,]=quadv(integrand, a=brts[t-1], b=brts[t+1], tol=1e-10)$Q
    Qt[t,]=negatives_correction(Qt[t,],pars) #it removes some small negative values that can occurr as bugs from the integration process

    #Selecting the state I am interested in
    vm = 1/choose((k+missnumspec),k)
    P  = vm * Qt[t,(missnumspec+1)] #I have to include +1 because of Q0

    #Removing C and D effects from the LL
    loglik = log(P) + logB - sum(log(C)) - sum(log(D))

    #Various checks
    loglik = as.numeric(loglik)
    if(is.nan(loglik) | is.na(loglik) ){loglik=-Inf}

    #CONDITIONING THE LIKELIHOOD ON THE SURVIVAL OF CROWN SPECIES
    Pc=1
    if ( (cond==1 | tips_interval[1]>1 | tips_interval[2]<Inf ) & !is.infinite(loglik) ){ #newest version

      total_time=max(abs(brts));times=c(0,total_time)
      m=0:max_number_of_species
      one_over_Cm=(3*(m+1))/(m+3)
      one_over_qm_binom=1/choose((m+N0),N0)
      tips_components=(1+min_tips):(1+min(max_tips,max_number_of_species)) #applying tips constrain

      Mk_N0=create_A(max_number_of_species = max_number_of_species,lambda = lambda,mu = mu,q = q,k = N0)
      A2_v1=A_operator(Q = Qt[1,],transition_matrix = Mk_N0,time_interval = total_time,precision = 50L,methode=methode,A_abstol=abstol,A_reltol=reltol)
      A2_v1=negatives_correction(A2_v1,pars) #it removes some small negative values that can occurr as bugs from the integration process
      total_product=A2_v1*one_over_Cm*one_over_qm_binom
      Pc=sum(total_product[tips_components])

      if (Pc==0){#slowest and best accuracy
        # ode_matrix=as.matrix(Mk_N0) #use this only if you use sparsematrices
        ode_matrix=MK_N0
        A2_v1=deSolve::ode(y = Qt[1,], times = times, func = MBD:::mbd_loglik_rhs, parms = ode_matrix,atol=abstol,rtol=reltol)[2,-1] #evolving crown species to the present
        total_product=A2_v1*one_over_Cm*one_over_qm_binom
        Pc=sum(total_product[tips_components])
      }

    }

    # if (Pc==0){Pc=sum(total_product); print("I have encountered a problem with conditional probability=0")} #sometimes, with expoRkit, some useful small values can be considered as zero. I cannot divide by zero, so I use this as a parachute
    loglik=loglik-log(Pc) #conditioned likelihood

  }
  # loglik=-loglik #Rampal's optimizer uses loglik rather than -loglik
  return(loglik)
}
