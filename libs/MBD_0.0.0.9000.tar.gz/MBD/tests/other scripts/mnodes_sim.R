N0=2;age=5;lambda1=0.4;lambda2=0.1;mu=0.2
total_count=N0;pool=c(-1,2)
N=N0
t=age
L = matrix(0,nrow=1e6,4)
L[,4]=-1
L[,3]=0
L[1,1:4] = c(t,0,-1,-1)
L[2,1:4] = c(t,-1,2,-1)
head(L)

while (t>0){
  N=length(pool)
  deltaT=rexp(1,rate=N*(lambda1+lambda2+mu))
  deltaN=sample(c(-1,1,2),size=1,prob = N*c(mu,lambda1,lambda2))
  t=t-deltaT
  if (deltaN>0 & t>0)
  {
    if (N>1) {parents=sample(pool,replace = F,size=deltaN)}else{parents=pool}
    new_interval=(total_count+1):(total_count+deltaN)
    L[new_interval,1]=t
    L[new_interval,2]=parents
    L[new_interval,3]=abs(new_interval)*sign(parents)

    pool=c(pool, abs(new_interval)*sign(parents) )
    total_count=total_count+deltaN
  }
  if (deltaN<0 & t>0)
  {
    if (N>1) {dead=sample(pool,replace = F,size=1)}else{dead=pool}
    L[abs(dead),4]=t
    pool=pool[pool!=dead]
  }
}
L=L[(1:total_count),]
births=unlist(unname(sort(DDD:::L2brts(L,dropextinct = T),decreasing = T)) )
tes = DDD:::L2phylo(L,dropextinct = T)
tas = DDD:::L2phylo(L,dropextinct = F)
plot(tes)
plot(tas)
print(births)
