mbd_loglik3 = function(pars,
                       beastoutput="simcophylo_1_RUN1.(time).trees.txt",
                       maxtree=10,
                       soc=2,
                       cond=0,
                       missnumspec=0){

brts = MBD:::extract_posterior(file_name = beastoutput,maxtree = maxtree)$brts
loglik=rep(NA,maxtree)
for (j in 1:maxtree){
loglik[j]=MBD:::mbd_loglik(pars=pars,
                 brts=brts[[j]],
                 soc=2,
                 cond=0,
                 tips_interval=c(0,Inf),
                 missnumspec=0,
                 safety_threshold = 1e-4,
                 methode = "both")
}
result=mean(loglik)
return(result)
}
