mbd_single_parameter_estimation = function (idpar=3, max_sims=1000,printoutput=0){
  load(paste(home_dir,'/mbd_like/sim_data',sep = ''),envir=.GlobalEnv) 
  max_sims=min(max_sims,length(sim_data))
  res=vector("list",max_sims)
  t0=proc.time()
  for (s in 1:max_sims){
    res[[s]]=mbd_minusLL_vs_single_parameter(s = s,FUN = mbd_loglik,missnumspec = 0,idpar = idpar,printoutput = 0) 
  }
  deltaT=proc.time()-t0;print(deltaT/max_sims)
  
  tips=unlist( lapply(sim_data,length) )[1:max_sims]+1
  
  q_est=unlist(lapply(res,"[[",1))
  
  if (printoutput==1){
    hist(q_est,breaks = ceiling(sqrt(max_sims)))
    plot(q_est~tips)
  }
  
  return(list(q_est,tips,res))
}