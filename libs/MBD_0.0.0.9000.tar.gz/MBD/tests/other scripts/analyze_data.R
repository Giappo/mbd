#MD_DATA_ANALYSIS#-------------------------------------------------------------------
#setup
require(plot3D); options(scipen = 4); require(boa);
results=unname(as.matrix(read.table( file.choose() ))); 
# results=unname(as.matrix(read.table(file.choose(),sep = ",")))
actual_values=c(sim_pars,sim_pars[2]/sim_pars[1],sim_pars[1]-sim_pars[2]);names(actual_values)=c("lambda","mu","q","mu/lambda","lambda-mu")
tree_size=NULL;if(dim(results)[2]>3){tree_size=results[,4]}
ratios=results[,2]/results[,1]
differences=results[,1]-results[,2]
results=cbind(results[,1:3],ratios,differences);if(dim(results)[2]>3){results=cbind(results,tree_size)}
data_medians=matrixStats::colMedians(results[,1:5]);rbind(data_medians,actual_values)
data_means=mean(results[,1:5]);data_sd=apply(results[,1:5], 2, sd);names(data_sd)=names(actual_values);rbind(data_means,data_sd,actual_values)

#hist
plot.new();par(mfrow=c(2,3))
hist(results[,1],breaks = 15,main = "lambda estimations",xlab = "lambda");abline(v=actual_values[1],col = "red")
hist(results[,2],breaks = 15,main = "mu estimations",xlab = "mu");abline(v=actual_values[2],col = "red")
hist(results[,3],breaks = 15,main = "q estimations",xlab = "q");abline(v=actual_values[3],col = "red")
hist(results[,4],breaks = 15,main = "mu/lambda estimations",xlab = "mu/lambda" );abline(v=actual_values[4],col = "red")
hist(results[,5],breaks = 15,main = "lambda-mu estimations",xlab = "lambda-mu" );abline(v=actual_values[5],col = "red")

#log hist
plot.new();par(mfrow=c(2,3))
hist(log(results[,1]),breaks = 15,main = "lambda estimations",xlab = "log(lambda)");abline(v=actual_values[1],col = "red")
hist(log(results[,2]),breaks = 15,main = "mu estimations",xlab = "log(mu)");abline(v=actual_values[1],col = "red")
hist(log(results[,3]),breaks = 15,main = "q estimations",xlab = "log(q)");abline(v=actual_values[1],col = "red")
hist(log(results[,4]),breaks = 15,main = "mu/lambda estimations",xlab = "log(mu/lambda)");abline(v=actual_values[4],col = "red")
hist(log(results[,5]),breaks = 15,main = "lambda-mu estimations",xlab = "log(lambda-mu)");abline(v=actual_values[5],col = "red")

#percentiles
percentiles=vector("list",5)
for (idpar in 1:5){percentiles[[idpar]]=quantile(results[,idpar], c(.25, .50, .75))}
percentiles=matrix(unlist(percentiles),nrow=5,ncol=3);colnames(percentiles)=c("25%","50%","75%")
cbind(percentiles,actual_values)

#correlation analysis
plot.new();par(mfrow=c(3,3));label_names=c("lambda","mu","q");
for (i in 1:3){
  for (j in 1:3){
    if (i==j){hist(log(results[,i]),main=NULL,breaks = 15,xlab = paste("log",label_names[i]));abline(v=actual_values[i],col = "red")}
else{plot(results[,i]~results[,j],xlab=label_names[i],ylab=label_names[j]);
  points(x=actual_values[i],y=actual_values[j],col="red")}
  }
}

#bootstrap analysis
max_boots=100000
bootstrapped_dataset=vector("list",max_boots)
media=matrix(NA,nrow = max_boots,ncol = 5)
for (s in 1:max_boots){
boot_rows=sample(x = 1:dim(results)[1],replace = T,size = dim(results)[1])
bootstrapped_dataset[[s]]=results[boot_rows,]
media[s,]=colMeans(bootstrapped_dataset[[s]])
}

plot.new();par(mfrow=c(2,3))
for (idpar in 1:5){
hist(media[,idpar],xlim=c(min(results[,idpar]),max(results[,idpar]))/4);abline(v=actual_values[idpar],col = "red")}
