mbd_minusLL_vs_single_parameter = function (s,FUN=mbd_loglik,idpar=3,missnumspec=0,printoutput=0){
  #This function shows likelihood behaviour as a function of one parameter. 
  #Specify parameter id with idpar (1 for lambda, 2 for mu, 3 for q)
  
  idparsfix=(1:3)[-idpar]
  load("sim_data"); load("general_settings");#mbd_setup()
  
  brts=sim_data[[s]];
  b_interval=seq(from=0.1,to=1.2,by=0.05);if(max(idparsfix==1)){b_interval=1};b=1;
  d_interval=seq(from=0,to=0.2,by=0.02);if(max(idparsfix==2)){d_interval=1};d=1;
  q_interval=seq(from=0.02,to=0.50, by=0.02);if(max(idparsfix==3)){q_interval=1};q=1;
  if(idpar==1){interval=b_interval};if(idpar==2){interval=d_interval};if(idpar==3){interval=q_interval};
  res=rep(NA,length(interval))
  for (i in 1:length(interval)){
    res[i]=mbd_loglik_choosepar(FUN=FUN,trparsopt=interval[i], trparsfix=sim_pars[idparsfix],idparsfix=idparsfix,
           brts=brts,N0=N0,soc=soc,tips_interval=tips_interval,missnumspec = missnumspec)
  }
  if (printoutput==1){
    plot(res~interval)
    title(paste("Simulation #",s))
  }
  best=interval[which(min(res)==(res))] #best estimation
  best=mean(best)
  sim=sim_pars[idpar] #actual value
  
  tips=length(sim_data[[s]])+1
  output=c(best,tips)
  write.table(matrix(output,ncol = length(output)),file = "mbd_singlepar_estimation.txt",append = T,row.names = F,col.names = F, sep = ",")
  
  return(list(best_value=best,sim_value=sim,all_values=res,parameter_interval=interval))
}
