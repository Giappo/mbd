#!/bin/bash

#echo "home_dir = substring(getwd(),1,13)" > temp_install_routine.R
#echo "libs_dir = paste(home_dir,'/mbd_like/libs',sep = '')" >> temp_install_routine.R
#echo "lib_files = list.files(pattern=paste('[.]tar',sep = ''),path=libs_dir, full.names=TRUE)" >> temp_install_routine.R
#echo "suppressWarnings(install.packages(lib_files, repos = NULL, type = "source"))" >> temp_install_routine.R

echo "OpenR --no-save"
echo "home_dir = substring(getwd(),1,13)" 
echo "libs_dir = paste(home_dir,'/mbd_like/libs',sep = '')"
echo "lib_files = list.files(pattern=paste('[.]tar',sep = ''),path=libs_dir, full.names=TRUE)"
echo "suppressWarnings(install.packages(lib_files, repos = NULL, type = "source"))"
echo "q()"


