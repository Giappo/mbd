#!/bin/bash

max_sims=1000

#echo "home_dir = substring(getwd(),1,13)" > zzza.R
#echo "lib_dir = paste(home_dir,'/libs',sep = '')" >> zzza.R
#echo "required_packages = list.files(pattern=paste('[.]tar.zip',sep = ''), path=lib_dir, full.names=TRUE)" >> 

echo "sbatch install_packages.bash"
echo "args = as.numeric(commandArgs(TRUE))" >> zzza.R
echo "mbd_ML_cluster(args)" >> zzza.R

for((s = 1; s <= max_sims; s++))
do

echo "#!/bin/bash" > mbd_ML_job_a$s
echo "#SBATCH --time=229:59:00" >> mbd_ML_job_a$s
echo "module load R/3.3.1-foss-2016a" >> mbd_ML_job_a$s
echo "Rscript zzza.R $s" >> mbd_ML_job_a$s
echo "rm mbd_ML_job_a$s" >> mbd_ML_job_a$s

sbatch --partition=nodes --mem=9GB --job-name=ML$s --mail-type=FAIL,TIME_LIMIT --mail-user=glaudanno@gmail.com mbd_ML_job_a$s
#--output=ML$s.log

done


#home_dir = substring(getwd(),1,13)
#project_dir = paste(home_dir,'/mbd_like',sep = '')
#lib_dir = paste(project_dir,'/libs',sep = '')
#required_packages = list.files(pattern=paste('[.]gz',sep = ''), path=lib_dir, full.names=TRUE)
#install.packages(required_packages, repos = NULL, type = "source")
