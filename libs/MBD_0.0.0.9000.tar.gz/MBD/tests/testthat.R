library(testthat)
library(MBD)

test_check("MBD")
