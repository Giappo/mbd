# context("basic")
#
# ## TODO: Rename context
# ## TODO: Add more tests
#
# test_that("multiplication works", {
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 5)
#   expect_equal(2 * 2, 4)
#   expect_equal(2 * 2, 4)
# })
