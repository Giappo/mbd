#include <boost/multiprecision/float128.hpp>
#include <boost/math/special_functions/gamma.hpp>
#include <vector>


using namespace boost::multiprecision;


template<typename T>
T factorial(int n)
{
  return boost::math::tgamma<T>(n + 1);
}


template <typename T>
class matrix
{
public:
  using value_type = T;

  matrix() : N_(0)
  {
  }

  explicit matrix(int N)
    : N_(N), A_(N*N, 0)
  {
  }

  matrix(matrix&& rhs) noexcept
    : N_(rhs.N_), A_(std::move(rhs.A_))
  {
    rhs.N_ = 0;
  }

  template <typename U>
  matrix& operator=(matrix<U>&& rhs) noexcept
  {
    matrix tmp(std::move(rhs));
    A_ = std::move(tmp.A_);
    return *this;
  }

  matrix(const matrix& rhs)
    : N_(rhs.N_), A_(rhs.A_)
  {
  }

  template <typename U>
  matrix(const matrix<U>& rhs)
    : N_(rhs.N()), A_(rhs.N()*rhs.N())
  {
    const size_t nn = A_.size();
    for (size_t i = 0; i < nn; ++i) A_[i] = static_cast<T>(rhs(i));
  }

  template <typename U>
  matrix& operator=(const matrix<U>& rhs)
  {
    matrix tmp(rhs);
    A_ = std::move(tmp.A_);
    return *this;
  }

  int N() const { return N_; }

    // linear access
  T operator()(int i) const noexcept { return A_[i]; }
  T& operator()(int i) noexcept { return A_[i]; }

  // element access
  T operator()(int i, int j) const noexcept { return A_[i + N_ * j]; }
  T& operator()(int i, int j) noexcept { return A_[i + N_ * j]; }

  // stl access
  auto begin() { return A_.begin(); }
  auto end() { return A_.end(); }
  auto cbegin() const { return A_.cbegin(); }
  auto cend() const { return A_.cend(); }

private:
  int N_;
  std::vector<T> A_;
};


template <typename T, typename FUN>
matrix<T> hyperA_impl(int N, int k, T q, FUN fun)
{
  matrix<T> A(N+1);
  for (int j = 0; j <= k; ++j) A(j,0) = fun(j);
  auto fk = factorial<T>(k);
  for (int s0 = 0; s0 < N; ++s0)
  {
    A(s0+1, s0+1) = A(s0, s0);
    int s1 = std::min(N-2, 2*s0+k);
    for (int s = s0; s <= s1; ++s) {
      A(s+2, s0+1) = A(s, s0) + A(s+1, s0);
    }
    for (int s = s0; s <= s1+2; ++s) {
      A(s, s0) *= fk * pow(q, (s-s0)) * pow(T(1) - q, 2*s0-s);
    }
  }
  A(N,N) *= fk * pow(T(1) - q, N);
  return std::move(A);
}


