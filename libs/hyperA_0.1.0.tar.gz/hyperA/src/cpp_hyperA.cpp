#include <Rcpp.h>
#include <algorithm>
#include "hyperA.hpp"


// [[Rcpp::plugins(cpp1y)]]


using namespace Rcpp;
using quad = float128;


// [[Rcpp::export]]
NumericMatrix cpp_hyperA(int N, int k, double q64, const std::string& fun)
{
  NumericMatrix A(N+1, N+1);
  try
  {
    quad q(q64);
    matrix<quad> A128;
    if (fun=="" || fun=="original")
    {
      auto Fun = [k, a_ = pow(1.0Q - q, k), b_ = (2.0Q)](int j) {
        return (a_ / (factorial<quad>(j) * factorial<quad>(k - j))) * pow(b_, j);
      };
      A128 = hyperA_impl<quad>(N, k, q, Fun);
    }
    std::transform(A128.cbegin(), A128.cend(), A.begin(), [](quad x){ return static_cast<double>(x); });
  }
  catch(std::exception &ex)
  {
    forward_exception_to_r(ex);
  }
  catch(...)
  {
    ::Rf_error("c++ exception (unknown reason)");
  }
  return A;
}
