# wrapper to cpp_hyperA

hyperA <- function(N, k, q, fun = "") {
  known_functions <- c("", "original")
  if (FALSE == fun %in% known_functions) stop(paste0("fun '", fun, "' not implemented."))
  cpp_hyperA(N,k,q,fun)
}
